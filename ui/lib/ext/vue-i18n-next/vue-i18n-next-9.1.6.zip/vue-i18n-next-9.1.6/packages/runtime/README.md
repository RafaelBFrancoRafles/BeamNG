# @intlify/runtime

The runtime for intlify project

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
