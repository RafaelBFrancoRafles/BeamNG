export const enum HelperNameMap {
  LIST = 'list',
  NAMED = 'named',
  PLURAL = 'plural',
  LINKED = 'linked',
  MESSAGE = 'message',
  TYPE = 'type',
  INTERPOLATE = 'interpolate',
  NORMALIZE = 'normalize'
}
