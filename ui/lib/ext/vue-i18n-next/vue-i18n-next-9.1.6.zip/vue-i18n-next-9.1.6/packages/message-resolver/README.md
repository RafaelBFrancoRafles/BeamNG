# @intlify/message-resolver

The locale message resolver for intlify project

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
