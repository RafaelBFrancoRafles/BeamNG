# @intlify/vue-devtools

The Vue DevTools I/F package for intlify project

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
