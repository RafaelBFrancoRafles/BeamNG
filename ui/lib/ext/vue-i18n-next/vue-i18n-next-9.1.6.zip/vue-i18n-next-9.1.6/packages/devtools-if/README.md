# @intlify/devtools-if

The [`@intlify/devtools`](https://github.com/intlify/devtools) interface(I/F:if) for intlify projects

## :warning: NOTE:

This is experimental.

Don’t use in production yet.

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
