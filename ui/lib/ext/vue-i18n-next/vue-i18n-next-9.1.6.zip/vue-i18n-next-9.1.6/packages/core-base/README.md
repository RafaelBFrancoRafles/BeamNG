# @intlify/core-base

The intlify core base module

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
