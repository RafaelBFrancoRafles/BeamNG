# @intlify/shared

The shared utility package for intlify project

## Forks
The implementation of this module is contains code forked from other packages or projects:

- [@vue/shared](https://github.com/vuejs/vue-next/tree/master/packages/shared)
  - Useful Utilities at `utils.ts`
    - Author: Evan You
    - License: MIT
  - Event Emitter at `emitter.ts` and `emittable.ts`
    - Author: Jason Miller
    - License: MIT

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
