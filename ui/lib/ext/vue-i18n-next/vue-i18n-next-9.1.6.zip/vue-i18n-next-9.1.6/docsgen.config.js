const linkReferencer = require('./scripts/api/resolver')
const processor = require('./scripts/api/processor')

module.exports = {
  linkReferencer,
  processor
}
