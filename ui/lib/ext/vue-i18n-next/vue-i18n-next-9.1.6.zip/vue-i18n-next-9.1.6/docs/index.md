---
home: true
heroImage: ./vue-i18n-logo.png
actionText: Get Started →
actionLink: introduction
features:
- title: Easy
  details: You can introduce internationalization into your app with simple API
- title: Powerful
  details: In addition to simple translation, support localization such as pluralization, number, datetime ... etc
- title: Component-oriented
  details: You can manage locale messages on single file component
footer: MIT Licensed | Copyright © 2020 kazuya kawaguchi
---
