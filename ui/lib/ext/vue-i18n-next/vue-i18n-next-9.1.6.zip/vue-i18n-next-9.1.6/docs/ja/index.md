---
home: true
heroImage: ./vue-i18n-logo.png
actionText: はじめよう →
actionLink: ja/introduction
features:
- title: 簡単
  details: シンプルなAPIでアプリにi18nを導入できます
- title: パワフル
  details: シンプルな翻訳に加え、複数化、数、日付時刻などのi18nもサポートします
- title: コンポーネント指向
  details: 単一のファイルコンポーネントでロケールメッセージを管理できます
footer: MIT Licensed | Copyright © 2020 kazuya kawaguchi
---
