# Backers

You can join them in supporting vue-i18n development by [pledging on Patreon](https://www.patreon.com/kazupon)! Backers in the same pledge level appear in the order of pledge date.

<h2 align="center">Gold Sponsors</h2>

<p align="center">
  <a
    href="https://nuxtjs.org/"
    style="margin: 1rem 1rem 0 1rem; width: 15rem; height: auto; display: inline-block; vertical-align: middle;"
    target="_blank"
    rel="noopener"
  >
    <img
      style="max-width: 100%; vertical-align: midele;"
      src="https://raw.githubusercontent.com/intlify/vue-i18n-next/master/docs/public/nuxt.png"
      width="260px"
      alt="Nuxt.js"
    >
  </a>
</p>

[It could be you!](https://github.com/sponsors/kazupon?o=esc)

<h2 align="center">Sliver Sponsors</h2>

<p align="center">
  <a
    href="https://www.codeandweb.com/babeledit?utm_campaign=vue-i18n-2019-01"
    style="margin: 1rem 1rem 0 1rem; width: 12rem; height: auto; display: inline-block; vertical-align: middle;"
    target="_blank"
    rel="noopener"
  >
    <img
      style="max-width: 100%; vertical-align: midele;"
      src="https://raw.githubusercontent.com/intlify/vue-i18n-next/master/docs/public/babeledit.png"
      width="200px"
      alt="Babel Edit"
    >
  </a>
</p>

[It could be you!](https://github.com/sponsors/kazupon?o=esc)

<h2 align="center">Bronze Sponsors</h2>

<p align="center">
  <a
    href="https://zenarchitects.co.jp/"
    style="margin: 1rem 1rem 0 1rem; width: 9rem; height: auto; display: inline-block; vertical-align: middle;"
    target="_blank"
    rel="noopener"
  >
    <img
      style="max-width: 100%; vertical-align: midele;"
      src="https://raw.githubusercontent.com/intlify/vue-i18n-next/master/docs/public/zenarchitects.png"
      width="140px"
      alt="Zen Architects"
    >
  </a>
</p>

<p align="center">
  <a
    href="https://www.sendcloud.com/"
    style="margin: 1rem 1rem 0 1rem; width: 9rem; height: auto; display: inline-block; vertical-align: middle;"
    target="_blank"
    rel="noopener"
  >
    <img
      style="max-width: 100%; vertical-align: midele;"
      src="https://raw.githubusercontent.com/intlify/vue-i18n-next/master/docs/public/sendcloud.png"
      width="140px"
      alt="Send Cloud"
    >
  </a>
</p>

<p align="center">
  <a
    href="https://www.vuemastery.com/"
    style="margin: 1rem 1rem 0 1rem; width: 9rem; height: auto; display: inline-block; vertical-align: middle;"
    target="_blank"
    rel="noopener"
  >
    <img
      style="max-width: 100%; vertical-align: midele;"
      src="https://raw.githubusercontent.com/intlify/vue-i18n-next/master/docs/public/vuemastery.png"
      width="140px"
      alt="Vue Mastery"
    >
  </a>
</p>

[It could be you!](https://github.com/sponsors/kazupon?o=esc)

<h2 align="center">Generous Supporters</h2>

[Currently vacant. It could be you!](https://github.com/sponsors/kazupon?o=esc)

<h2 align="center">Awesome Supporters</h2>

- Shinya Katayama

[It could be you!](https://github.com/sponsors/kazupon?o=esc)
