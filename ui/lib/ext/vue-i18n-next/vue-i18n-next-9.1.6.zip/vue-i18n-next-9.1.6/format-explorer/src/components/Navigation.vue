<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Navigation'
})
</script>

<template>
  <h2>Intlify Message Format Explorer</h2>
  <!-- eslint-disable-next-line vue/no-multiple-template-root -->
  <ul>
    <li>
      <!-- prettier-ignore -->
    </li>
  </ul>
</template>

<style scoped>
h2 {
  margin: 0;
  margin-left: 2rem;
  display: inline-block;
}
ul {
  list-style-type: none;
  display: inline-block;
}
</style>
