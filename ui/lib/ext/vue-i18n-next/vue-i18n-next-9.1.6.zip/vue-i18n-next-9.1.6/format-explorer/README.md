# @intlify/message-format-explorer

intlify message format explorer

## :cd: Installation

```sh
$ npm install
```

## :rocket: Run the format explorer

```sh
$ npm run dev
```

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
