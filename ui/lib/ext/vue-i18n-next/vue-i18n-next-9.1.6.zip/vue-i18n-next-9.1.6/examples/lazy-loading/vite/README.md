# :lollipop: lazy-loading-vite

i18n locale messages lazy loading examples for Vite


## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
