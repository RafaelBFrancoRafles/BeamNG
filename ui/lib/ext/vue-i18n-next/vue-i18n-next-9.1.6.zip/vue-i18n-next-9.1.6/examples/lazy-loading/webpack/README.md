# :lollipop: lazy-loading-webpack

i18n locale messages lazy loading examples for webpack


## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
