<template>
  <h2>{{ $t('pages.home') }}</h2>
</template>
