<template>
  <h2>{{ $t('pages.about') }}</h2>
</template>
